/*
 * @author David Pascual y Cristian Tatu
 */
package tipos;

// TODO: Auto-generated Javadoc
/**
 * Tipos de oferta.
 *
 * @author David Pascual y Cristian Tatu
 */
public enum TipoOferta {
	
	/** The vacacional. */
	VACACIONAL, 
	
	/** The vivienda. */
	VIVIENDA;
}